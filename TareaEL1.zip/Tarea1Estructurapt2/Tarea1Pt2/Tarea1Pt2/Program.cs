﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1Pt2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 7//
            bool valid = true;
            while (valid){
                Console.WriteLine("Ejercicio 7");
                Console.WriteLine("Operaciones Algebraicas con 2 números");
                Console.WriteLine("Seleccione operación y luego presione Enter para continuar\n1. Adición\n2. Sustracción\n3. Multiplicación\n4. División\n5 Salir.");
                int operacion = int.Parse(Console.ReadLine());
                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                Console.Clear();
                switch (operacion){
                    case 1:
                        Console.WriteLine("Adición");
                        Console.WriteLine("Primer número: ");
                        float sum1 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Segundo número: ");
                        float sum2 = float.Parse(Console.ReadLine());
                        float suma = sum1 + sum2;
                        Console.WriteLine("La suma de " + sum1 + " y " + sum2 + " es: " + suma);
                        Console.WriteLine("Presione Enter para continuar");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                        operacion = 0;
                        valid = true;
                    break;
                    case 2:
                        Console.WriteLine("Sustracción");
                        Console.WriteLine("Escriba primer número: ");
                        float rest1 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Escriba segundo número: ");
                        float rest2 = float.Parse(Console.ReadLine());
                        float resta = rest1 - rest2;
                        Console.WriteLine("La sustracción de " + rest1 + " y " + rest2 + " es: " + resta);
                        Console.WriteLine("Presion Enter para continuar");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                        operacion = 0;
                        valid = true;
                    break;
                    case 3:
                        Console.WriteLine("Multiplicación");
                        Console.WriteLine("Escriba primer número: ");
                        float mult1 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Escriba segundo número: ");
                        float mult2 = float.Parse(Console.ReadLine());
                        float mult = mult1 * mult2;
                        Console.WriteLine("La multiplicación de " + mult1 + " y " + mult2 + " es: " + mult);
                        Console.WriteLine("Presion Enter para continuar");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                        operacion = 0;
                        valid = true;
                        break;
                        case 4:
                            Console.WriteLine("División");
                            Console.WriteLine("Escriba primer número: ");
                            float div1 = float.Parse(Console.ReadLine());
                            Console.WriteLine("Escriba segundo número: ");
                            float div2 = float.Parse(Console.ReadLine());
                            float div = div1 / div2;
                            Console.WriteLine("La división de " + div1 + " y " + div2 + " es: " + div);
                            Console.WriteLine("Presion Enter para continuar");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                            operacion = 0;
                            valid = true;
                            break;
                        case 5:
                        Console.WriteLine("Salir");
                        Console.WriteLine("Desea Salir\n1. Si\n2. No\nPresione Enter después de seleccionar número");
                        int salir = int.Parse(Console.ReadLine());
                        Console.Clear();

                        switch (salir){
                            case 1:
                                Console.WriteLine("Fin del programa");
                                Console.WriteLine("Presione Esc");
                                while (Console.ReadKey().Key != ConsoleKey.Escape) { }
                                valid = false;
                                break;
                            case 2:
                                Console.WriteLine("Regresar al menu");
                                Console.Clear();
                                operacion = 0;
                                valid = true;
                                break;
                            default:
                                Console.WriteLine("Selección invalida, no te pases de listo otra vez\nEnter para regresar al Menú de salida");
                                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                Console.Clear();
                                operacion = 0;
                                valid = true;
                                break;
                        }
                        break;
                        default:
                        Console.WriteLine("Selección invalida, no te pases de listo\nEnter para regresar al Menú de inicio");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                        operacion = 0;
                        valid = true;
                        break;
                }
            
            }

        }
    }
}
