﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1Estructurapt1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 1//
            Console.WriteLine("Hola Billy Samayoa");
            Console.WriteLine("Presiona Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 2//
        
            Console.WriteLine("Ejercicio 2\nEscriba Primer Número para la suma");
            double num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba segundo Número");
            double num2 = double.Parse(Console.ReadLine());
            double suma = num1 + num2;

            Console.WriteLine("La suma de "+num1+" + "+num2+" es: "+suma);
            Console.WriteLine("Presione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

        
            //Ejercicio 3//

            Console.WriteLine("Ejercicio 3\nEscriba primer número para dividir");
            double numdiv1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba segundo número");
            double numdiv2 = double.Parse(Console.ReadLine());

            Console.WriteLine("La division entre {0} y {1} es: {2}", numdiv1, numdiv2, numdiv1 / numdiv2);
            Console.WriteLine("Presione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 4//
            Console.WriteLine("Ejercicio 4\nOperaciones Algebraicas");
            double nume1 = 1, nume2 = 3, nume3 = 5, nume4 = 25, nume5 = 0.07, nume6 = 15, nume7 = -4, nume8 = 6, nume9 = 11, nume10 = 2, nume11 = 10;

            Console.WriteLine("El resultado de -{0}+{1}*{2} es: {3}", nume1, nume2, nume3, -nume1 + nume2 * nume3);
            Console.WriteLine("El resultado de ({0}+{1})*{2} es: {3}", nume4, nume3, nume5, (nume4 + nume3) * nume5);
            Console.WriteLine("El resultado de {0}+{1}+{2}/{3} es: {4}", nume6, nume7, nume8, nume9, nume6 + nume7 * nume8 / nume9);
            Console.WriteLine("El resultado de {0}+{1}/{2}*{3}-{4}*{5} es {6}", nume10, nume11, nume8, nume1, nume5, nume10, nume10 + nume11 / nume8 * nume1 - nume5 * nume10);

            Console.WriteLine("Presione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 5//
            Console.WriteLine("Ejercicio5\nIntercambio de numeros");
            Console.WriteLine("Escriba primer número");
            int numer1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Escriba segundo número");
            int numer2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Primer número es {0} y segundo número es {1}, intercambiando queda como primer número {2} y segundo {3}.", numer1, numer2, numer2, numer1);
            Console.WriteLine("Presione Enter para Continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 6//
            Console.WriteLine("Ejercicio6\nMultiplicación de tres números enteros");
            Console.WriteLine("Ingrese primer número");
            int numero1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese segundo número");
            int numero2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese tercer número");
            int numero3 = int.Parse(Console.ReadLine());
            int Mult = numero1 * numero2 * numero3;

            Console.WriteLine("La multiplicación de "+numero1+"*"+numero2+"*"+numero3+" es " +Mult);
            Console.WriteLine("Presione Esc para salir del programa");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }
            Console.Clear();
                             
        }
    }
}
