﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 8//
            Console.WriteLine("Ejercicio 8\nTablas de multiplicar");
            Console.WriteLine("Seleccione un número que sera multiplicado del 1 al 10");
            int num1 = int.Parse(Console.ReadLine());
            int mul1 = num1 * 1;
            int mul2 = num1 * 2;
            int mul3 = num1 * 3;
            int mul4 = num1 * 4;
            int mul5 = num1 * 5;
            int mul6 = mul1 * 6;
            int mul7 = mul1 * 7;
            int mul8 = mul1 * 8;
            int mul9 = mul1 * 9;
            int mul10 = mul1 * 10;


            Console.WriteLine("La tabla de multiplicar del " + num1 + " es: \n" + num1 + " * 1 es " + mul1 + "\n" + num1 + " * 2 es " + mul2 + "\n" + num1 + " * 3 es " + mul3);
            Console.WriteLine(+num1 + " * 4 es " + mul4 + "\n" + num1 + " * 5 es " + mul5 + "\n" + num1 + " * 6 es " + mul6);
            Console.WriteLine(+num1 + " * 7 es " + mul7 + "\n" + num1 + " * 8 es " + mul8 + "\n" + num1 + " * 9 es " + mul9 + "\n" + num1 + " * 10 es " + mul10);
            Console.WriteLine("Presione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 9//
            Console.WriteLine("Ejercicio 9");
            Console.WriteLine("En esta carrera se lleva cuatro cursos de matemática, sacar el promedio total de los cuatro cursos sacados este año\nCada número que coloque presione Enter");
            Console.WriteLine("Escriba la primera nota");
            double prom1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba la segunda nota");
            double prom2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba la tercera nota");
            double prom3 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba la cuarta nota");
            double prom4 = double.Parse(Console.ReadLine());
            double promt = (prom1 + prom2 + prom3 + prom4) / 4;
            Console.WriteLine("El promedio total es: " + promt + " de 100");
            Console.WriteLine("Presione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 10//
            Console.WriteLine("Ejercicio 10");
            Console.WriteLine("Tome tres números (x, y, z) para resolver las siguientes ecuaciones\n1. (x + y) * z\n2.y*x + x +y*z ");
            Console.WriteLine("\nIngrese el dato `x´");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("\nIngrese el dato `y´");
            int y = int.Parse(Console.ReadLine());
            Console.WriteLine("\nIngrese el dato `z´");
            int z = int.Parse(Console.ReadLine());
            int eq1 = (x + y) * z;
            int eq2 = y * x + x + y * z;
            Console.WriteLine("\nEl resultado de la ecuación (x + y) * z cuando x=" + x + " y=" + y + " z=" + z + " es: \n" + eq1);
            Console.WriteLine("\nEl resultado de la ecuación y*x + x +y*z cuando x=" + x + " y=" + y + " z=" + z + " es: \n" + eq2);
            Console.WriteLine("\nPresione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();


            //Ejercicio 11//
            Console.WriteLine("Ejercicio 11\nSaber si la persona presente es menor o mayor de edad\nIngrese su edad por favor:");
            int edad = int.Parse(Console.ReadLine());
            if (edad > 18)
            {
                Console.WriteLine("Mayor de edad, te vez mayor de " + edad);
            }
            else
            {
                Console.WriteLine("Menor de edad, muchacho te vez menor de " + edad);
            }
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 12//
            Console.WriteLine("Ejercicio 12\nColoque el número para mostrar la secuencia\nLuego de eso presione Enter");
            int nume = int.Parse(Console.ReadLine());
            Console.WriteLine("Secuencia\n");
            Console.WriteLine("" + nume + " " + nume + " " + nume + " " + nume + "\n" + nume + "" + nume + "" + nume + "" + nume + "\n" + nume + " " + nume + " " + nume + " " + nume + "\n" + nume + "" + nume + "" + nume + "" + nume);
            Console.WriteLine("\nPresione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 13//
            Console.WriteLine("Ejercicio 13\nDemostración de un rectángulo de 3 columnas de ancho y 5 filas de altura usando el dígito que inserte");
            int numero = int.Parse(Console.ReadLine());
            Console.WriteLine("\nFigura\n");
            Console.WriteLine(+numero + "" + numero + "" + numero + "\n" + numero + " " + numero + "\n" + numero + " " + numero + "\n" + numero + " " + numero + "\n" + numero + "" + numero + "" + numero);
            Console.WriteLine("\nPresione Enter para continuar");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            Console.Clear();

            //Ejercicio 14//
            Console.WriteLine("Ejercicio 14\nConvertidor de grados Celsius a Fahrenheit y Kelvin");
            Console.WriteLine("Escriba los grados");
            double grados = double.Parse(Console.ReadLine());
            double f = grados * (9 / 5) + 32;
            double k = grados + 273;
            Console.WriteLine("\n" + grados + "°C es " + f + "°F");
            Console.WriteLine("\n" + grados + "°C es " + k + "°F");
            Console.WriteLine("\nPresione Esc para salir del programa");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }
            
            

        }
    }
}
